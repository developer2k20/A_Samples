﻿var app;

app = angular.module('appmodule',[]);
﻿function ViewModel() {
    var self = this;

    var tokenKey = 'accessToken';
    var RefTokenKey = 'refreshToken';
    self.result = ko.observable();
    self.user = ko.observable();

    self.registerEmail = ko.observable();
    self.registerPassword = ko.observable();
    self.registerPassword2 = ko.observable();

    self.loginEmail = ko.observable();
    self.loginPassword = ko.observable();
    self.token = ko.observable();
    self.refreshToken = ko.observable();
    function showError(jqXHR) {
        self.result(jqXHR.status + ': ' + jqXHR.statusText);
    }

    self.callApi = function () {

        self.result('');

        var token = sessionStorage.getItem(tokenKey);

        var headers = {};
        if (token) {
            headers.Authorization = 'Bearer ' + token;
        }

        $.ajax({
            type: 'GET',
            url: '/api/values',
            headers: headers
        }).done(function (data) {
            self.result(data);
        }).fail(showError);
    }

    self.callToken = function () {
        self.result('');
        // alert(self.loginEmail());
        // alert(self.loginPassword());
        var loginData = {
            grant_type: 'password',
            username: self.loginEmail(),
            password: self.loginPassword()
        };

        $.ajax({
            type: 'POST',
            url: '/Token',
            data: loginData
        }).done(function (data) {
            self.user(data.userName);
            // Cache the access token in session storage.
            sessionStorage.setItem(tokenKey, data.access_token);
            var tkn = sessionStorage.getItem(tokenKey);
            $("#tknKey").val(tkn);
        }).fail(showError);
    }

    self.register = function () {
        self.result('');

        var data = {
            Email: self.registerEmail(),
            Password: self.registerPassword(),
            ConfirmPassword: self.registerPassword2()
        };

        $.ajax({
            type: 'POST',
            url: '/api/Account/Register',
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data)
        }).done(function (data) {
            self.result("Done!");
        }).fail(showError);
    }

    // testing for login call

    self.login = function () {
        self.result('');
        alert("login call");
        var loginData = {
            grant_type: 'password',
            username: self.loginEmail(),
            password: self.loginPassword()
        };

        $.ajax({
            type: 'POST',
            url: '/Token',
            data: loginData
        }).done(function (data) {
            self.user(data.userName);
            sessionStorage.setItem(tokenKey, data.access_token);
            sessionStorage.setItem(RefTokenKey, data.refresh_token);

        }).fail(showError);
    }


    self.logout = function () {
        self.user('');
        sessionStorage.removeItem(tokenKey)
    }


    self.RefreshToken = function () {
        // self.refreshToken('');
        // var ref = sessionStorage.getItem(RefTokenKey);
        // $("#rfstkn").val(ref);

        self.result('');

        var loginData = {
            grant_type: 'password',
            username: self.loginEmail(),
            password: self.loginPassword()
        };

        $.ajax({
            type: 'POST',
            url: '/Token',
            data: loginData
        }).done(function (data) {
            self.user(data.userName);
            // Cache the access token in session storage.
            //sessionStorage.setItem(tokenKey, data.access_token);
            sessionStorage.setItem(RefTokenKey, data.refresh_token);
            var ref = sessionStorage.getItem(RefTokenKey);
            $("#rfstkn").val(ref);
        }).fail(showError);
    }
}

var app = new ViewModel();
ko.applyBindings(app);
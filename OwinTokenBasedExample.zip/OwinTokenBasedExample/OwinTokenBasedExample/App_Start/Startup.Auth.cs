﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.Google;
using Microsoft.Owin.Security.OAuth;
using Owin;
using OwinTokenBasedExample.Providers;
using OwinTokenBasedExample.Models;
using Microsoft.Owin.Security.Infrastructure;

namespace OwinTokenBasedExample
{
    public partial class Startup
    {
        public static OAuthAuthorizationServerOptions OAuthOptions { get; private set; }

        public static string PublicClientId { get; private set; }

        // For more information on configuring authentication, please visit http://go.microsoft.com/fwlink/?LinkId=301864
        public void ConfigureAuth(IAppBuilder app)
        {
            app.CreatePerOwinContext(ApplicationDbContext.Create);
            app.CreatePerOwinContext<ApplicationUserManager>(ApplicationUserManager.Create);
            app.UseCookieAuthentication(new CookieAuthenticationOptions());
           // app.UseExternalSignInCookie(DefaultAuthenticationTypes.ExternalCookie);
            PublicClientId = "self";
            OAuthOptions = new OAuthAuthorizationServerOptions
            {
                TokenEndpointPath = new PathString("/Token"),
                Provider = new ApplicationOAuthProvider(PublicClientId),
                RefreshTokenProvider = new AuthenticationTokenProvider()
                {
                    OnCreate = CreateRefreshToken,
                    OnReceive = RecieveRefreshToken
                },
                AuthorizeEndpointPath = new PathString("/api/Account/ExternalLogin"),
                AccessTokenExpireTimeSpan = TimeSpan.FromDays(10),
                AllowInsecureHttp = true,

            };

            app.UseOAuthBearerTokens(OAuthOptions);
        }

        private static void RecieveRefreshToken(AuthenticationTokenReceiveContext obj)
        {
            //throw new NotImplementedException();
            obj.DeserializeTicket(obj.Token);
        }

        private static void CreateRefreshToken(AuthenticationTokenCreateContext obj)
        {
            // throw new NotImplementedException();
            obj.SetToken(obj.SerializeTicket());
        }
    }
}

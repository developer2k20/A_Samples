﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        static int id;
        static int index;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                id = 0;
                index = -1;
                using (var context = new EmployeesEntities())
                {
                    var contextList = from c in context.Emps select c;

                    grdEmployees.DataSource = contextList.ToList();
                    grdEmployees.DataBind();
                }
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Emp emp = new Emp();
            emp.EmpName = txtName.Text;
            emp.EmpAddress = txtAddress.Text;
            emp.EmpPhoneNumber = Convert.ToInt32(txtPhone.Text);

            using (var context = new EmployeesEntities())
            {
                context.Emps.Add(emp);
                context.SaveChanges();

                var contextList = from c in context.Emps select c;

                grdEmployees.DataSource = contextList.ToList();
                grdEmployees.DataBind();
            }
        }

        protected void grdEmployees_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                index = Convert.ToInt32(e.CommandArgument);
                id = Convert.ToInt32(grdEmployees.Rows[index].Cells[1].Text);

                using (var context = new EmployeesEntities())
                {
                    var contextList = from c in context.Emps where c.ID.Equals(id) select c;

                    foreach (var em in contextList)
                    {
                        txtName.Text = em.EmpName;
                        txtAddress.Text = em.EmpAddress;
                        txtPhone.Text = em.EmpPhoneNumber.ToString();
                    }
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            using (var context = new EmployeesEntities())
            {
                var contextList = context.Emps.ToList<Emp>();
                Emp selectedrecord = contextList.Where(cl => cl.ID == id).FirstOrDefault<Emp>();
                
                selectedrecord.EmpName = txtName.Text;
                selectedrecord.EmpAddress = txtAddress.Text;
                selectedrecord.EmpPhoneNumber = Convert.ToInt32(txtPhone.Text);

                context.SaveChanges();

                var selectContext = from c in context.Emps select c;

                grdEmployees.DataSource = selectContext.ToList();
                grdEmployees.DataBind();
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            using (var context = new EmployeesEntities())
            {
                var contextList = context.Emps.ToList<Emp>();
                context.Emps.Remove(contextList.ElementAt<Emp>(index));

                context.SaveChanges();

                var selectContext = from c in context.Emps select c;

                grdEmployees.DataSource = selectContext.ToList();
                grdEmployees.DataBind();
            }
        }


    }
}